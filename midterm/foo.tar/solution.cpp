#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <iomanip>
#include "wordsearch.h"
#include "wordsearch_sol.h"

using namespace std;

bool find_word(char** puzzle, int n, string word, char dir, int r, int c)
{
	int r_inc = 0, c_inc = 0;
	if(dir == 'L')
	{
		c_inc = 1;
		if(c+word.size() > n)
		{
			return false;
		}
	}
	else if(dir == 'T')
	{
		r_inc = 1;
		if(r+word.size() > n)
		{
			return false;
		}
	}
	else if(dir == 'D')
	{
		r_inc = c_inc = 1;
		if(r+word.size() > n || c+word.size() > n)
		{
			return false;
		}
	}
	bool found=true;
	int len = word.size();
	int i = 0;
	while(len > 0)
	{
		if(puzzle[r][c] != word[i])
		{
			found = false;
			break;
		}
		r += r_inc;
		c += c_inc;
		len--;
		i++;
	}
	return found;
}

bool find_word_s(char** puzzle, int n, string word, char dir, int r, int c)
{
	int r_inc = 0, c_inc = 0;
	if(dir == 'L')
	{
		c_inc = 1;
		if(c+word.size() > n)
		{
			return false;
		}
	}
	else if(dir == 'T')
	{
		r_inc = 1;
		if(r+word.size() > n)
		{
			return false;
		}
	}
	else if(dir == 'D')
	{
		r_inc = c_inc = 1;
		if(r+word.size() > n || c+word.size() > n)
		{
			return false;
		}
	}
	bool found=true;
	int len = word.size();
	int i = 0;
	while(len > 0)
	{
		if(puzzle[r][c] != word[i])
		{
			found = false;
			break;
		}
		r += r_inc;
		c += c_inc;
		len--;
		i++;
	}
	return found;
}

bool load_words(char** puzzle, int n, const char* fname)
{
	ifstream ifile(fname);
	if(ifile.fail())
	{
		return false;
	}
	int num;
	ifile >> num;
	if(ifile.fail() || num == 0)
	{
		return false;
	}
	for(int i=0;i<num;i++)
	{
		int r, c;
		char d;
		string w;
		ifile >> r >> c >> d >> w;
		if(ifile.fail())
		{
			return false;
		}
		place_word(puzzle, n, w, d, r, c);

	}
	return true;
}

bool load_words_s(char** puzzle, int n, const char* fname)
{
	ifstream ifile(fname);
	if(ifile.fail())
	{
		return false;
	}
	int num;
	ifile >> num;
	if(ifile.fail() || num == 0)
	{
		return false;
	}
	for(int i=0;i<num;i++)
	{
		int r, c;
		char d;
		string w;
		ifile >> r >> c >> d >> w;
		if(ifile.fail())
		{
			return false;
		}
		place_word(puzzle, n, w, d, r, c);

	}
	return true;
}

char** new_puzzle(int n)
{
	char** puzzle = new char*[n];
	for(int i=0;i<n;i++)
	{
		puzzle[i] = new char[n];
	}
	return puzzle;
}

char** new_puzzle_s(int n)
{
	char** puzzle = new char*[n];
	for(int i=0;i<n;i++)
	{
		puzzle[i] = new char[n];
	}
	return puzzle;
}

void print_puzzle(char** puzzle, int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout << setw(3) << puzzle[i][j];
		}
		cout << endl;
	}
}

void print_puzzle_s(char** puzzle, int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			cout << setw(3) << puzzle[i][j];
		}
		cout << endl;
	}
}


bool place_word(char** puzzle, int n, string word, char dir, int r, int c)
{
	int r_inc = 0, c_inc = 0;
	if(dir == 'L')
	{
		c_inc = 1;
		if(c+word.size() > n)
		{
			
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}
	else if(dir == 'T')
	{
		r_inc = 1;
		if(r+word.size() > n)
		{
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}
	else if(dir == 'D')
	{
		r_inc = c_inc = 1;
		if(r+word.size() > n || c+word.size() > n)
		{
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}

	int len = word.size();
	int i = 0;
	while(len > 0)
	{
		puzzle[r][c] = word[i];
		r += r_inc;
		c += c_inc;
		len--;
		i++;
	}
	return true;
}

bool place_word_s(char** puzzle, int n, string word, char dir, int r, int c)
{
	int r_inc = 0, c_inc = 0;
	if(dir == 'L')
	{
		c_inc = 1;
		if(c+word.size() > n)
		{
			
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}
	else if(dir == 'T')
	{
		r_inc = 1;
		if(r+word.size() > n)
		{
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}
	else if(dir == 'D')
	{
		r_inc = c_inc = 1;
		if(r+word.size() > n || c+word.size() > n)
		{
			cout << "Invalid word placement: " << word << " " << dir << "@" << r << "," << c << endl;
			return false;
		}
	}

	int len = word.size();
	int i = 0;
	while(len > 0)
	{
		puzzle[r][c] = word[i];
		r += r_inc;
		c += c_inc;
		len--;
		i++;
	}
	return true;
}

char random_letter()
{
	return (char)( (rand()%25)+'A');	
}

char random_letter_s()
{
	return (char)( (rand()%25)+'A');	
}

char random_letter_s();

void random_puzzle(char** puzzle, int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			puzzle[i][j] = random_letter_s();
		}
	}
}

void random_puzzle_s(char** puzzle, int n)
{
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			puzzle[i][j] = random_letter_s();
		}
	}
}

bool search_word(char** puzzle, int n, string word, int *x, int* y, char* d)
{
	char dirs[3] = {'L','T','D'};
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<3;k++)
			{
				bool f = find_word_s(puzzle, n, word, dirs[k], i, j);
				if(f)
				{
					*x = i;
					*y = j;
					*d = dirs[k];
					return true;
				}
			}
		}
	}
	return false;
}

bool search_word_s(char** puzzle, int n, string word, int *x, int* y, char* d)
{
	char dirs[3] = {'L','T','D'};
	for(int i=0;i<n;i++)
	{
		for(int j=0;j<n;j++)
		{
			for(int k=0;k<3;k++)
			{
				bool f = find_word_s(puzzle, n, word, dirs[k], i, j);
				if(f)
				{
					*x = i;
					*y = j;
					*d = dirs[k];
					return true;
				}
			}
		}
	}
	return false;
}

