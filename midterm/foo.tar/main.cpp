#include <iostream>
#include <fstream>
#include <cstdlib>
#include <string>
#include <iomanip>
#include "wordsearch.h"

using namespace std;

int main(int argc, char const *argv[])
{
	if(argc < 4)
	{
		cout << "Not enough command line arguments." << endl;
		return 1;
	}
	srand(atoi(argv[1]));
	int n = atoi(argv[2]);

	char** my_puzzle = new_puzzle(n);
	random_puzzle(my_puzzle,n);
	load_words(my_puzzle, n, argv[3]);
	print_puzzle(my_puzzle,n);

	string look;
	cout << "Enter a word: " << endl;
	while(cin >> look)
	{
		int x=0;
		int y=0;
		char d='X';
		if(search_word(my_puzzle, n, look, &x, &y, &d))
		{
			cout << "Word " << look << " found @ " << x << " " << y << endl;
		}
		else
		{
			cout << "Word " << look << " not foud." << endl;
		}
	}
	/* code */
	return 0;
}

